// File: app/src/main/java/com/glass/launcher/LauncherManager.kt

package com.glass.launcher

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import androidx.compose.runtime.mutableStateOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ==================== APP DATA MODEL ====================
data class AppInfo(
    val packageName: String,
    val appName: String,
    val icon: Drawable? = null,
    val isSystemApp: Boolean = false
)

// ==================== LAUNCHER MANAGER ====================
class LauncherManager(private val context: Context) {
    
    private val packageManager = context.packageManager
    val installedApps = mutableStateOf<List<AppInfo>>(emptyList())
    
    // Load all installed apps
    suspend fun loadInstalledApps() {
        withContext(Dispatchers.Default) {
            try {
                val apps = mutableListOf<AppInfo>()
                
                // Query all packages
                val packages = packageManager.getInstalledPackages(
                    PackageManager.GET_CONFIGURATIONS
                )
                
                for (packageInfo in packages) {
                    try {
                        val appLabel = packageManager.getApplicationLabel(packageInfo.applicationInfo)
                        val appIcon = packageManager.getApplicationIcon(packageInfo.applicationInfo)
                        
                        // Filter out system apps (optional)
                        val isSystemApp = (packageInfo.applicationInfo.flags and 
                                ApplicationInfo.FLAG_SYSTEM) != 0
                        
                        apps.add(
                            AppInfo(
                                packageName = packageInfo.packageName,
                                appName = appLabel.toString(),
                                icon = appIcon,
                                isSystemApp = isSystemApp
                            )
                        )
                    } catch (e: Exception) {
                        // Skip apps that can't be loaded
                    }
                }
                
                // Sort by app name (case-insensitive)
                apps.sortBy { it.appName.lowercase() }
                
                // Update state
                installedApps.value = apps
                
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
    
    // Launch app by package name
    fun launchApp(packageName: String) {
        try {
            val intent = packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    
    // Get app icon by package name
    fun getAppIcon(packageName: String): Drawable? {
        return try {
            packageManager.getApplicationIcon(packageName)
        } catch (e: Exception) {
            null
        }
    }
    
    // Get app label by package name
    fun getAppLabel(packageName: String): String {
        return try {
            packageManager.getApplicationLabel(
                packageManager.getApplicationInfo(packageName, 0)
            ).toString()
        } catch (e: Exception) {
            packageName
        }
    }
    
    // Uninstall app
    fun uninstallApp(packageName: String) {
        try {
            val intent = Intent(Intent.ACTION_DELETE).apply {
                data = android.net.Uri.parse("package:$packageName")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    
    // Open app info settings
    fun openAppInfo(packageName: String) {
        try {
            val intent = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = android.net.Uri.parse("package:$packageName")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    
    // Get all apps sorted by name
    fun getAppsByCategory(category: String = "all"): List<AppInfo> {
        return when (category) {
            "system" -> installedApps.value.filter { it.isSystemApp }
            "user" -> installedApps.value.filter { !it.isSystemApp }
            else -> installedApps.value
        }
    }
    
    // Search apps
    fun searchApps(query: String): List<AppInfo> {
        if (query.isEmpty()) return installedApps.value
        
        return installedApps.value.filter { app ->
            app.appName.contains(query, ignoreCase = true) ||
            app.packageName.contains(query, ignoreCase = true)
        }
    }
}
