// File: app/src/main/java/com/glass/launcher/MainActivity.kt

package com.glass.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.glass.launcher.ui.screens.HomeScreen
import com.glass.launcher.ui.theme.GlassTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        setContent {
            GlassTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.Transparent
                ) {
                    // Glassmorphism Background with gradient
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                brush = Brush.verticalGradient(
                                    colors = listOf(
                                        Color(0xFF0A0E27), // Deep dark blue
                                        Color(0xFF1A1F3A), // Dark purple-blue
                                        Color(0xFF0D1929)  // Almost black
                                    )
                                )
                            )
                    ) {
                        // Main launcher UI
                        HomeScreen()
                    }
                }
            }
        }
    }
}

// Launcher Setup Activity - For setting as default home
class LauncherSetupActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        setContent {
            GlassTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.Transparent
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                brush = Brush.verticalGradient(
                                    colors = listOf(
                                        Color(0xFF0A0E27),
                                        Color(0xFF1A1F3A),
                                        Color(0xFF0D1929)
                                    )
                                )
                            )
                    ) {
                        HomeScreen()
                    }
                }
            }
        }
    }
}
