// File: app/src/main/java/com/glass/launcher/ui/utils/AnimationUtils.kt

package com.glass.launcher.ui.utils

import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Easing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.TransformOrigin

// ==================== EASING CURVES ====================
object GlassEasings {
    // Smooth entrance
    val smoothEnter: Easing = CubicBezierEasing(0.25f, 0.46f, 0.45f, 0.94f)
    
    // Smooth exit
    val smoothExit: Easing = CubicBezierEasing(0.25f, 0.1f, 0.25f, 1f)
    
    // Elastic bounce
    val elasticBounce: Easing = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1f)
    
    // Smooth slide
    val smoothSlide: Easing = CubicBezierEasing(0.35f, 0f, 0.65f, 1f)
    
    // Material standard (recommended for most animations)
    val material = FastOutSlowInEasing
}

// ==================== ANIMATION DURATIONS ====================
object AnimationDurations {
    const val Fast = 200              // Quick interactions
    const val Normal = 400            // Standard animations
    const val Slow = 600              // Emphasized animations
    const val Entrance = 700          // Screen entrance
    const val Exit = 500              // Screen exit
}

// ==================== ANIMATION SPECS ====================
object AnimationSpecs {
    // Quick entrance (button press, hover)
    fun quickEnter(): AnimationSpec<Float> =
        tween(
            durationMillis = AnimationDurations.Fast,
            easing = GlassEasings.smoothEnter
        )
    
    // Standard entrance
    fun standardEnter(): AnimationSpec<Float> =
        tween(
            durationMillis = AnimationDurations.Normal,
            easing = GlassEasings.smoothEnter
        )
    
    // Emphasized entrance (screens, large elements)
    fun emphasizedEnter(): AnimationSpec<Float> =
        tween(
            durationMillis = AnimationDurations.Entrance,
            easing = GlassEasings.smoothEnter
        )
    
    // Quick exit
    fun quickExit(): AnimationSpec<Float> =
        tween(
            durationMillis = AnimationDurations.Fast,
            easing = GlassEasings.smoothExit
        )
    
    // Standard exit
    fun standardExit(): AnimationSpec<Float> =
        tween(
            durationMillis = AnimationDurations.Exit,
            easing = GlassEasings.smoothExit
        )
    
    // Smooth slide (drawer, menu)
    fun smoothSlide(): AnimationSpec<Float> =
        tween(
            durationMillis = AnimationDurations.Normal,
            easing = GlassEasings.smoothSlide
        )
    
    // Elastic bounce (attention grabber)
    fun elasticBounce(): AnimationSpec<Float> =
        tween(
            durationMillis = AnimationDurations.Slow,
            easing = GlassEasings.elasticBounce
        )
    
    // Material standard (safe default)
    fun material(): AnimationSpec<Float> =
        tween(
            durationMillis = AnimationDurations.Normal,
            easing = GlassEasings.material
        )
}

// ==================== SCALE ANIMATIONS ====================
object ScaleAnimations {
    val pressScale = 0.95f              // Button press effect
    const val hoverScale = 1.05f        // Hover scale
    const val focusScale = 1.02f        // Focus scale
    const val selectedScale = 1.1f      // Selected item scale
}

// ==================== ALPHA ANIMATIONS ====================
object AlphaAnimations {
    const val Transparent = 0f
    const val Subtle = 0.3f
    const val Moderate = 0.6f
    const val Full = 1f
}

// ==================== ROTATION ANIMATIONS ====================
object RotationAnimations {
    const val None = 0f
    const val Slight = 3f
    const val Quarter = 90f
    const val Half = 180f
    const val Full = 360f
}

// ==================== BLUR ANIMATION HELPER ====================
object BlurAnimations {
    const val Minimal = 1f
    const val Light = 4f
    const val Medium = 8f
    const val Heavy = 12f
    const val VeryHeavy = 16f
}

// ==================== TRANSFORM ORIGIN PRESETS ====================
object TransformOriginPresets {
    val topStart = TransformOrigin(0f, 0f)
    val topCenter = TransformOrigin(0.5f, 0f)
    val topEnd = TransformOrigin(1f, 0f)
    
    val centerStart = TransformOrigin(0f, 0.5f)
    val center = TransformOrigin(0.5f, 0.5f)
    val centerEnd = TransformOrigin(1f, 0.5f)
    
    val bottomStart = TransformOrigin(0f, 1f)
    val bottomCenter = TransformOrigin(0.5f, 1f)
    val bottomEnd = TransformOrigin(1f, 1f)
}

// ==================== COMMON ANIMATION PATTERNS ====================
object AnimationPatterns {
    
    // Fade in + scale up (entrance)
    data class FadeScaleIn(
        val startAlpha: Float = 0f,
        val endAlpha: Float = 1f,
        val startScale: Float = 0.8f,
        val endScale: Float = 1f,
        val durationMillis: Int = AnimationDurations.Normal
    )
    
    // Fade out + scale down (exit)
    data class FadeScaleOut(
        val startAlpha: Float = 1f,
        val endAlpha: Float = 0f,
        val startScale: Float = 1f,
        val endScale: Float = 0.8f,
        val durationMillis: Int = AnimationDurations.Normal
    )
    
    // Slide in from edge
    data class SlideInEdge(
        val fromX: Float = -1000f,  // Negative = left
        val fromY: Float = 0f,
        val toX: Float = 0f,
        val toY: Float = 0f,
        val durationMillis: Int = AnimationDurations.Normal
    )
    
    // Slide out to edge
    data class SlideOutEdge(
        val fromX: Float = 0f,
        val fromY: Float = 0f,
        val toX: Float = 1000f,     // Positive = right
        val toY: Float = 0f,
        val durationMillis: Int = AnimationDurations.Normal
    )
    
    // Bounce effect
    data class BounceEffect(
        val intensity: Float = 20f,  // Bounce distance in dp
        val cycles: Int = 3,         // Number of bounces
        val durationMillis: Int = AnimationDurations.Slow
    )
    
    // Shake effect
    data class ShakeEffect(
        val intensity: Float = 10f,  // Shake distance in dp
        val frequency: Int = 4,      // Shakes per animation
        val durationMillis: Int = 500
    )
}
