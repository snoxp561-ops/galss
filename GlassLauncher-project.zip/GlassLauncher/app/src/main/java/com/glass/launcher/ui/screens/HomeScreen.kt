// File: app/src/main/java/com/glass/launcher/ui/screens/HomeScreen.kt

package com.glass.launcher.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDrag
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.glass.launcher.ui.components.GlassAppIcon
import com.glass.launcher.ui.components.GlassClockWidget
import com.glass.launcher.ui.components.GlassDock
import com.glass.launcher.ui.components.GlassFolder
import com.glass.launcher.ui.components.GlassSearchBar
import com.glass.launcher.ui.components.GlassStatusBar
import com.glass.launcher.ui.theme.GlassColors
import com.glass.launcher.ui.theme.GlassDimensions
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

// ==================== HOME SCREEN ====================
@Composable
fun HomeScreen() {
    val showAppDrawer = remember { mutableStateOf(false) }
    val offsetY = remember { Animatable(0f) }
    val currentTime = remember { mutableStateOf("10:30") }
    val currentDate = remember { mutableStateOf("Jun 13") }
    
    // Update time every second
    LaunchedEffect(Unit) {
        while (true) {
            val now = LocalDateTime.now()
            currentTime.value = now.format(DateTimeFormatter.ofPattern("HH:mm"))
            currentDate.value = now.format(DateTimeFormatter.ofPattern("MMM dd"))
            kotlinx.coroutines.delay(1000)
        }
    }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectVerticalDrag { change, dragAmount ->
                    if (dragAmount > 50) { // Swipe up
                        showAppDrawer.value = true
                    }
                }
            }
    ) {
        // Main Home Screen
        if (!showAppDrawer.value) {
            HomeScreenContent(
                onShowDrawer = { showAppDrawer.value = true },
                currentTime = currentTime.value,
                currentDate = currentDate.value
            )
        } else {
            // App Drawer
            AppDrawerScreen(
                onClose = { showAppDrawer.value = false }
            )
        }
    }
}

// ==================== HOME SCREEN CONTENT ====================
@Composable
fun HomeScreenContent(
    onShowDrawer: () -> Unit,
    currentTime: String,
    currentDate: String
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Status Bar
        GlassStatusBar(
            time = currentTime,
            batteryPercent = 85,
            signalStrength = 4
        )
        
        // Large padding
        Box(modifier = Modifier.height(20.dp))
        
        // Clock Widget (Centered)
        GlassClockWidget(
            time = currentTime,
            date = currentDate,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        
        Box(modifier = Modifier.height(24.dp))
        
        // Search Bar
        GlassSearchBar()
        
        Box(modifier = Modifier.height(20.dp))
        
        // Quick App Grid
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            contentPadding = PaddingValues(GlassDimensions.paddingMedium),
            horizontalArrangement = Arrangement.spacedBy(GlassDimensions.paddingSmall),
            verticalArrangement = Arrangement.spacedBy(GlassDimensions.paddingSmall),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = GlassDimensions.paddingSmall)
                .height(300.dp)
        ) {
            items(8) { index ->
                val apps = listOf(
                    "Phone", "Messages", "Chrome", "Gmail",
                    "Maps", "Photos", "Settings", "Play Store"
                )
                
                GlassAppIcon(
                    appName = apps[index],
                    onClick = { /* Open app */ }
                )
            }
        }
        
        Box(modifier = Modifier.height(20.dp))
        
        // Folders Section
        Text(
            text = "Quick Access",
            style = androidx.compose.material3.MaterialTheme.typography.titleMedium,
            color = GlassColors.textSecondary,
            modifier = Modifier
                .align(Alignment.Start)
                .padding(start = GlassDimensions.paddingMedium)
        )
        
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(GlassDimensions.paddingMedium),
            horizontalArrangement = Arrangement.spacedBy(GlassDimensions.paddingMedium)
        ) {
            GlassFolder(
                name = "Games",
                appCount = 5,
                onClick = { /* Open folder */ },
                modifier = Modifier.weight(1f)
            )
            
            GlassFolder(
                name = "Tools",
                appCount = 8,
                onClick = { /* Open folder */ },
                modifier = Modifier.weight(1f)
            )
            
            GlassFolder(
                name = "Social",
                appCount = 3,
                onClick = { /* Open folder */ },
                modifier = Modifier.weight(1f)
            )
        }
        
        Box(modifier = Modifier.height(30.dp))
        
        // Settings Button
        IconButton(
            onClick = { /* Open settings */ },
            modifier = Modifier.align(Alignment.End)
        ) {
            Icon(
                imageVector = Icons.Filled.Settings,
                contentDescription = "Settings",
                tint = GlassColors.textSecondary,
                modifier = Modifier.padding(GlassDimensions.paddingMedium)
            )
        }
        
        Box(modifier = Modifier.height(80.dp))
    }
    
    // Floating Dock at Bottom
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = GlassDimensions.paddingMedium),
        contentAlignment = Alignment.BottomCenter
    ) {
        GlassDock(
            apps = listOf("Phone", "Messages", "Chrome", "Apps")
        )
    }
}

// ==================== APP DRAWER SCREEN ====================
@Composable
fun AppDrawerScreen(
    onClose: () -> Unit
) {
    val offsetY = remember { Animatable(200f) }
    
    LaunchedEffect(Unit) {
        offsetY.animateTo(0f, animationSpec = tween(durationMillis = 400))
    }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.5f))
            .pointerInput(Unit) {
                detectVerticalDrag { change, dragAmount ->
                    if (dragAmount < -50) { // Swipe down
                        onClose()
                    }
                }
            }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .offset(y = offsetY.value.dp)
                .background(
                    color = GlassColors.bgDark.copy(alpha = 0.95f)
                )
                .padding(GlassDimensions.paddingMedium)
        ) {
            // Header
            Text(
                text = "All Apps",
                style = androidx.compose.material3.MaterialTheme.typography.headlineSmall,
                color = GlassColors.textPrimary,
                modifier = Modifier.padding(bottom = GlassDimensions.paddingMedium)
            )
            
            // Apps Grid
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                contentPadding = PaddingValues(GlassDimensions.paddingSmall),
                horizontalArrangement = Arrangement.spacedBy(GlassDimensions.paddingSmall),
                verticalArrangement = Arrangement.spacedBy(GlassDimensions.paddingSmall)
            ) {
                items(32) { index ->
                    val appNames = listOf(
                        "Phone", "Messages", "Chrome", "Gmail",
                        "Maps", "Photos", "Settings", "Play Store",
                        "YouTube", "WhatsApp", "Instagram", "Facebook",
                        "Twitter", "Telegram", "Discord", "Spotify",
                        "Netflix", "Amazon", "Flipkart", "Uber",
                        "Zomato", "Swiggy", "Twitter", "Reddit",
                        "Medium", "Dev.to", "Slack", "Teams",
                        "Zoom", "Google Meet", "Notes", "Calendar"
                    )
                    
                    GlassAppIcon(
                        appName = appNames[index % appNames.size],
                        onClick = { /* Open app */ }
                    )
                }
            }
        }
        
        // Close hint
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = GlassDimensions.paddingXLarge)
        ) {
            Text(
                text = "↓ Swipe down to close",
                style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                color = GlassColors.textTertiary,
                textAlign = TextAlign.Center
            )
        }
    }
}

import kotlinx.coroutines.delay
