// File: app/src/main/java/com/glass/launcher/ui/components/GlassComponents.kt

package com.glass.launcher.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.glass.launcher.ui.theme.GlassBlurEffects
import com.glass.launcher.ui.theme.GlassColors
import com.glass.launcher.ui.theme.GlassDimensions

// ==================== GLASS CARD ====================
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    blurIntensity: Float = 0.3f,
    borderAlpha: Float = 0.4f,
    cornerRadius: Dp = GlassDimensions.cornerRadiusMedium,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(cornerRadius))
            .background(
                color = Color(0x4DFFFFFF).copy(alpha = blurIntensity)
            )
            .border(
                width = GlassDimensions.borderWidth,
                color = Color.White.copy(alpha = borderAlpha),
                shape = RoundedCornerShape(cornerRadius)
            )
            .then(
                if (onClick != null) {
                    Modifier.clickable(onClick = onClick)
                } else {
                    Modifier
                }
            )
    ) {
        content()
    }
}

// ==================== GLASS ICON BUTTON ====================
@Composable
fun GlassIconButton(
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    icon: @Composable () -> Unit,
    label: String = "",
    size: Dp = GlassDimensions.iconLarge
) {
    Column(
        modifier = modifier
            .size(size + GlassDimensions.paddingMedium)
            .clip(RoundedCornerShape(GlassDimensions.cornerRadiusMedium))
            .background(
                color = GlassColors.glassLight.copy(alpha = 0.2f)
            )
            .border(
                width = 1.5.dp,
                color = Color.White.copy(alpha = 0.3f),
                shape = RoundedCornerShape(GlassDimensions.cornerRadiusMedium)
            )
            .clickable(onClick = onClick)
            .padding(GlassDimensions.paddingSmall),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(modifier = Modifier.size(size)) {
            icon()
        }
        if (label.isNotEmpty()) {
            Text(
                text = label,
                style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                color = GlassColors.textSecondary,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

// ==================== GLASS APP ICON ====================
@Composable
fun GlassAppIcon(
    modifier: Modifier = Modifier,
    appName: String,
    onClick: () -> Unit,
    isSelected: Boolean = false
) {
    Column(
        modifier = modifier
            .size(80.dp)
            .clip(RoundedCornerShape(GlassDimensions.cornerRadiusLarge))
            .background(
                color = if (isSelected) {
                    GlassColors.neonBlue.copy(alpha = 0.2f)
                } else {
                    Color(0x1AFFFFFF)
                }
            )
            .border(
                width = 1.5.dp,
                color = if (isSelected) {
                    GlassColors.neonBlue.copy(alpha = 0.6f)
                } else {
                    Color.White.copy(alpha = 0.25f)
                },
                shape = RoundedCornerShape(GlassDimensions.cornerRadiusLarge)
            )
            .clickable(onClick = onClick)
            .padding(GlassDimensions.paddingSmall),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // App Icon Placeholder
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(
                    color = GlassColors.neonBlue.copy(alpha = 0.3f)
                )
        ) {
            Icon(
                imageVector = Icons.Filled.Apps,
                contentDescription = appName,
                modifier = Modifier
                    .size(32.dp)
                    .align(Alignment.Center),
                tint = GlassColors.neonBlue
            )
        }
        
        // App Label
        Text(
            text = appName,
            style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
            color = GlassColors.textPrimary,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .padding(top = 6.dp)
                .padding(horizontal = 4.dp)
        )
    }
}

// ==================== GLASS CLOCK WIDGET ====================
@Composable
fun GlassClockWidget(
    modifier: Modifier = Modifier,
    time: String = "10:30",
    date: String = "Jun 13"
) {
    GlassCard(
        modifier = modifier
            .size(GlassDimensions.clockWidgetSize)
            .padding(GlassDimensions.paddingMedium),
        blurIntensity = 0.25f
    ) {
        Column(
            modifier = Modifier
                .padding(GlassDimensions.paddingMedium)
                .align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Time
            Text(
                text = time,
                style = androidx.compose.material3.MaterialTheme.typography.headlineSmall,
                color = GlassColors.neonBlue,
                fontSize = 32.sp
            )
            
            // Date
            Text(
                text = date,
                style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                color = GlassColors.textSecondary
            )
        }
    }
}

// ==================== GLASS DOCK ====================
@Composable
fun GlassDock(
    modifier: Modifier = Modifier,
    apps: List<String> = listOf("Phone", "Messages", "Contacts", "Browser")
) {
    GlassCard(
        modifier = modifier
            .padding(horizontal = GlassDimensions.paddingMedium)
            .padding(bottom = GlassDimensions.paddingMedium),
        blurIntensity = 0.2f,
        borderAlpha = 0.35f
    ) {
        Row(
            modifier = Modifier
                .padding(GlassDimensions.paddingSmall),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            apps.forEach { app ->
                GlassIconButton(
                    modifier = Modifier.weight(1f),
                    onClick = {},
                    icon = {
                        Icon(
                            imageVector = Icons.Filled.Apps,
                            contentDescription = app,
                            modifier = Modifier.size(GlassDimensions.iconMedium),
                            tint = GlassColors.neonBlue
                        )
                    },
                    label = app,
                    size = GlassDimensions.iconMedium
                )
            }
        }
    }
}

// ==================== GLASS STATUS BAR ====================
@Composable
fun GlassStatusBar(
    modifier: Modifier = Modifier,
    time: String = "10:30",
    batteryPercent: Int = 85,
    signalStrength: Int = 4
) {
    Row(
        modifier = modifier
            .padding(GlassDimensions.paddingMedium),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left side - Signal & Battery icons
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "📶",
                fontSize = 16.sp
            )
            Text(
                text = "🔋 $batteryPercent%",
                style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                color = GlassColors.textSecondary
            )
        }
        
        // Center - Time
        Text(
            text = time,
            style = androidx.compose.material3.MaterialTheme.typography.titleSmall,
            color = GlassColors.textPrimary
        )
        
        // Right side - Connection
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "📡",
                fontSize = 16.sp
            )
            Text(
                text = "4G",
                style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                color = GlassColors.textSecondary
            )
        }
    }
}

// ==================== GLASS SEARCH BAR ====================
@Composable
fun GlassSearchBar(
    modifier: Modifier = Modifier,
    onSearch: (String) -> Unit = {}
) {
    GlassCard(
        modifier = modifier
            .padding(GlassDimensions.paddingMedium),
        blurIntensity = 0.25f
    ) {
        Row(
            modifier = Modifier
                .padding(GlassDimensions.paddingMedium),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(GlassDimensions.paddingSmall)
        ) {
            Icon(
                imageVector = Icons.Filled.Apps,
                contentDescription = "Search",
                modifier = Modifier.size(24.dp),
                tint = GlassColors.textSecondary
            )
            
            Text(
                text = "🔍 Search apps...",
                style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                color = GlassColors.textTertiary,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

// ==================== GLASS FOLDER ====================
@Composable
fun GlassFolder(
    modifier: Modifier = Modifier,
    name: String,
    appCount: Int,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .size(80.dp)
            .clip(RoundedCornerShape(GlassDimensions.cornerRadiusLarge))
            .background(
                color = Color(0x1AFFFFFF)
            )
            .border(
                width = 1.5.dp,
                color = Color.White.copy(alpha = 0.25f),
                shape = RoundedCornerShape(GlassDimensions.cornerRadiusLarge)
            )
            .clickable(onClick = onClick)
            .padding(GlassDimensions.paddingSmall),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Folder Icon
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(
                    color = GlassColors.neonPurple.copy(alpha = 0.3f)
                )
        ) {
            Text(
                text = "📁",
                fontSize = 28.sp,
                modifier = Modifier.align(Alignment.Center)
            )
        }
        
        // Folder Name
        Text(
            text = name,
            style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
            color = GlassColors.textPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp)
        )
        
        // App Count Badge
        Text(
            text = "$appCount",
            style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
            color = GlassColors.neonPurple,
            fontSize = 10.sp
        )
    }
}

import androidx.compose.ui.unit.sp
