// File: app/src/main/java/com/glass/launcher/ui/theme/ThemeConfig.kt

package com.glass.launcher.ui.theme

import androidx.compose.foundation.isSystemInDarkMode
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

// ==================== GLASSMORPHISM COLORS ====================
object GlassColors {
    // Primary Glass Surfaces
    val glassLight = Color(0x99FFFFFF) // 60% opacity white
    val glassDark = Color(0x4D000000)  // 30% opacity black
    val glassMedium = Color(0x66FFFFFF) // 40% opacity white
    
    // Background
    val bgDark = Color(0xFF0A0E27)     // Deep blue-black
    val bgMedium = Color(0xFF1A1F3A)   // Medium dark blue
    val bgLight = Color(0xFF2A3555)    // Lighter blue
    
    // Accent Colors (Neon)
    val neonBlue = Color(0xFF00D4FF)   // Cyan neon
    val neonPurple = Color(0xFFBB00FF) // Purple neon
    val neonPink = Color(0xFFFF006E)   // Pink neon
    val neonGreen = Color(0xFF00FF88)  // Green neon
    
    // Status Colors
    val success = Color(0xFF00FF88)
    val warning = Color(0xFFFFAA00)
    val error = Color(0xFFFF0040)
    
    // Text Colors
    val textPrimary = Color(0xFFFFFFFF)
    val textSecondary = Color(0xFFB0B8D4)
    val textTertiary = Color(0xFF7A8299)
}

// ==================== GLASS THEME ====================
@Composable
fun GlassTheme(
    darkTheme: Boolean = isSystemInDarkMode(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) {
        darkColorScheme(
            primary = GlassColors.neonBlue,
            onPrimary = GlassColors.bgDark,
            secondary = GlassColors.neonPurple,
            onSecondary = Color.White,
            tertiary = GlassColors.neonPink,
            onTertiary = Color.White,
            background = GlassColors.bgDark,
            onBackground = GlassColors.textPrimary,
            surface = GlassColors.glassMedium,
            onSurface = GlassColors.textPrimary,
            error = GlassColors.error,
            onError = Color.White
        )
    } else {
        // Light theme (though launcher is dark-first)
        darkColorScheme(
            primary = GlassColors.neonBlue,
            onPrimary = Color.White,
            secondary = GlassColors.neonPurple,
            background = Color.White,
            surface = GlassColors.glassLight
        )
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = GlassTypography,
        content = content
    )
}

// ==================== GLASS DIMENSIONS ====================
object GlassDimensions {
    val paddingXSmall = 4.dp
    val paddingSmall = 8.dp
    val paddingMedium = 16.dp
    val paddingLarge = 24.dp
    val paddingXLarge = 32.dp
    
    val cornerRadiusSmall = 8.dp
    val cornerRadiusMedium = 16.dp
    val cornerRadiusLarge = 24.dp
    val cornerRadiusXLarge = 32.dp
    
    val borderWidth = 1.5.dp
    val borderWidthThick = 2.dp
    
    // Icon sizes
    val iconSmall = 24.dp
    val iconMedium = 36.dp
    val iconLarge = 48.dp
    val iconXLarge = 64.dp
    
    // Widget sizes
    val clockWidgetSize = 120.dp
    val appIconSize = 48.dp
    val dockHeight = 80.dp
}

// ==================== GLASS BLUR EFFECTS ====================
object GlassBlurEffects {
    const val blurRadiusSmall = 4f
    const val blurRadiusMedium = 8f
    const val blurRadiusLarge = 12f
    const val blurRadiusXLarge = 16f
}

// ==================== TYPOGRAPHY ====================
import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val GlassTypography = Typography(
    headlineLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 32.sp,
        color = GlassColors.textPrimary
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp,
        color = GlassColors.textPrimary
    ),
    headlineSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 24.sp,
        color = GlassColors.textPrimary
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 20.sp,
        color = GlassColors.textPrimary
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        color = GlassColors.textPrimary
    ),
    titleSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        color = GlassColors.textSecondary
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        color = GlassColors.textPrimary
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        color = GlassColors.textSecondary
    ),
    bodySmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        color = GlassColors.textTertiary
    ),
    labelLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp,
        color = GlassColors.textPrimary
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        color = GlassColors.textSecondary
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        color = GlassColors.textTertiary
    )
)
