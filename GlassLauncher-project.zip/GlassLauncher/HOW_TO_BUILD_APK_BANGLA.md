# 🚀 GlassLauncher APK — ফ্রি-তে অনলাইনে বিল্ড করুন (GitHub Actions)

এই environment-এ ইন্টারনেট/Android SDK নেই, তাই সরাসরি APK বানানো সম্ভব নয়। কিন্তু আমি পুরো প্রজেক্টটা সঠিকভাবে সাজিয়ে দিয়েছি + একটা **GitHub Actions workflow** যুক্त করেছি যা **সম্পূর্ণ ফ্রি**-তে cloud-এ APK বিল্ড করে দেবে। মাত্র ৫ মিনিট সময় লাগবে।

## ধাপগুলো:

1. **GitHub-এ একটা নতুন repository খুলুন** (public বা private, যেকোনোটা) — যেমন `GlassLauncher`।

2. এই zip-টা extract করে সব ফাইল ওই repository-তে push করুন:
   ```bash
   git init
   git add .
   git commit -m "Glass Launcher initial commit"
   git branch -M main
   git remote add origin https://github.com/<your-username>/GlassLauncher.git
   git push -u origin main
   ```
   (বা GitHub ওয়েবসাইটে গিয়ে "Upload files" বাটন দিয়ে সব ফাইল drag & drop করুন)

3. Push করার সাথে সাথে **Actions** ট্যাবে গিয়ে দেখবেন "Build Glass Launcher APK" workflow নিজে থেকেই রান হচ্ছে (২-৪ মিনিট সময় লাগে)।

4. বিল্ড শেষ হলে, ওই workflow run-এর নিচে **Artifacts** সেকশনে `GlassLauncher-debug-apk` নামে একটা zip পাবেন — সেটা ডাউনলোড করুন। এর ভিতরে `app-debug.apk` থাকবে।

5. APK ফোনে কপি করে install করুন (Unknown Sources permission দিতে হতে পারে)।

## যদি workflow না চলে:
- Repository → **Actions** ট্যাবে গিয়ে "I understand my workflows, go ahead and enable them" বাটনে ক্লিক করুন (নতুন repo-তে প্রথমবার manual enable লাগে)।
- তারপর "Build Glass Launcher APK" workflow সিলেক্ট করে **Run workflow** বাটনে ক্লিক করুন।

## যা যুক্ত করা হয়েছে (যা আগের zip-এ ছিল না/ভাঙা ছিল):
- ✅ সব ফাইল সঠিক ফোল্ডার স্ট্রাকচারে সাজানো হয়েছে
- ✅ `gradle.properties` (AndroidX enable) যুক্ত করা হয়েছে
- ✅ App icon resources (`ic_launcher`, adaptive icon) যুক্ত করা হয়েছে — আগে এগুলো ছিল না, যার ফলে build **ফেল হতো**
- ✅ `.github/workflows/build-apk.yml` — ফ্রি cloud build pipeline

GitHub Actions সম্পূর্ণ **ফ্রি** (public repo-তে unlimited, private repo-তেও মাসে 2000 মিনিট ফ্রি)। কোনো Android Studio বা SDK লাগবে না আপনার কম্পিউটারে।
